# Jalal Expense Manager

A mobile-friendly, offline-capable expense tracker with local device storage.

## Included features
- Add, edit and delete expenses
- PKR currency
- Daily, weekly, monthly and yearly reporting
- Category breakdown and spending charts
- Monthly budget, budget remaining and net cash balance (income minus expenses)
- Income records
- Search, category and month filters
- JSON backup and restore
- Optional 4–8 digit PIN lock
- English / Urdu direction toggle (Urdu mode currently translates the welcome greeting and switches layout direction; most labels remain English)
- PWA manifest and service worker for offline use after first load

## Run as a web app
Open `index.html` in a browser. For install/offline PWA behavior, serve the folder over HTTPS or localhost, then use the browser's **Install app** / **Add to Home Screen** option.

## Android Studio project
The `android/` folder is a minimal native Android WebView wrapper project. Open the `android` folder in Android Studio, allow Gradle sync, then select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- Package: `com.jalal.expensemanager`
- Minimum Android: API 23
- Compile SDK: 35

If Android Studio asks to install Android SDK 35 or a compatible Gradle JDK, install the suggested components.
The Android wrapper loads the bundled `index.html` from app assets and works offline.

## Data and privacy
All records are stored locally in the app/browser storage on the device. No account or cloud server is used. Export JSON backups regularly. Uninstalling the Android app or clearing app storage may erase local data. PIN lock is a convenience lock, not bank-grade encryption; do not use it as protection against a technically skilled attacker.

## Project files
- `index.html` — complete app interface and logic
- `manifest.webmanifest` — PWA metadata
- `service-worker.js` — offline cache
- `android/` — Android Studio WebView wrapper
